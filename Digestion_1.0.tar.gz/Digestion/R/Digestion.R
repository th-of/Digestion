#----------------------------------------------------------------------------
#define class "Digestion" with the slots "Restriction", "DNASequence", "Digest", "RestrictionSite" and "Cut"
#----------------------------------------------------------------------------
setClass("Digestion", representation(Restriction="character", DNASequence="ANY",Digest="data.frame", RestrictionSite ="character", Cut="character"))
#----------------------------------------------------------------------------   



#Constructor for 'getRestriction', named 'getRestrictionEnzyme'
getRestrictionEnzyme <- function(Restriction)     
              { 
               a <- new(Class="Digestion", Restriction=Restriction)              #Call class 'Digestion' with slot 'Restriction'
               b <- getRestriction(a)                                            #get name of the restriction enzymes
               return(b)                                                         #return a data.frame with the letter code, name and cut of a restriction enzyme
              }
#------------------------------------------------------------------------------

#Constructor for 'digest', named 'getDigestionFragments'
getDigestionFragments <- function(Restriction, DNASequence)     
              { 
               a <- new(Class="Digestion", Restriction=Restriction, DNASequence=DNASequence)              #Call class 'Digestion' with slot 'Restriction' and 'DNASequence'
               b <- digest(a)                                                                   #digest the DNASequence
               return(b)                                                                        #return a data.frame with all cuts of the restriction enzyme in the DNASequence
              }
#------------------------------------------------------------------------------

#Constructor for 'plotDigest', named 'plotDigestion'
plotDigestion <- function(Restriction, DNASequence)
              { 
              a <- new(Class="Digestion", Restriction=Restriction, DNASequence=DNASequence)
              b <- digest(a)                                            #digest the DNASequence first with the restriction enzyme(s)
              if(length(b)<=1)
            { e <- "ERROR: restriction enzyme or DNASequence must be wrong."
              return(e)}else{
              d <- new(Class="Digestion", Digest=b)
              e <- plotDigest(d)                                        #plot the digestion
              }
              }
#----------------------------------------------------------------------------------              

#Constructor for 'getName', named 'getRestrictionName'
getRestrictionName <- function(RestrictionSite)     
              { 
               a <- new(Class="Digestion", RestrictionSite=RestrictionSite)    #call class 'Digestion' with the slot 'RestrictionSite'     
               b <- getName(a)                                                 #get the name of the restriction enzyme                                                          
               return(b)                                                                   
              }
#------------------------------------------------------------------------------

#Constructor for 'writeRestriction', named 'NewRestriction'
NewRestriction <- function(Restriction, RestrictionSite, Cut)
              { 
              a <- new(Class="Digestion", Restriction=Restriction, RestrictionSite=RestrictionSite, Cut=Cut)  #call class 'Digestion' with slots 'Restriction','RestrictionSite' and 'Cut'
              b <- writeRestriction(a)                                      #write a new table
              }
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------


#set generic for 'getRestriction'
setGeneric("getRestriction", function(object){standardGeneric("getRestriction")})
#--------------------------------------------------------------------------------
#set method 'getRestriction', this method returns the letter code and the cut of restriction enzymes. The needed slot is 'Restriction', which contains the name of the restriction enzyme.
setMethod ("getRestriction", "Digestion",                                        
     function(object){
     
     a <- as.character(subset(allRestrictionEnzymes$restriction,allRestrictionEnzymes$name==object@Restriction))   
                    
     #in 'object@Restriction' is the name of the restriction enzyme, allRestricitonEnzymes is a table, which contains all restriction enzymes we found.
     if(length(a)>0)
     {R <- a                     #define the letter code as R and RRev 
     lengt <- nchar(a)
     RRev <- a                  #Translate the letter code of the restriction enzyme by the UipacCode.
     R <- gsub("Y","[CT]",R)    #Y is C or T
     R <- gsub("R","[AG]",R)    #R is A or G
     R <- gsub("W","[AT]",R)    # ...
     R <- gsub("S","[CG]",R)    # ...
     R <- gsub("K","[GT]",R)    # ...
     R <- gsub("M","[AC]",R)    # ...
     R <- gsub("B","[CGT]",R)
     R <- gsub("D","[AGT]",R)
     R <- gsub("H","[ACT]",R)
     R <- gsub("V","[ACG]",R)
     R <- gsub("N","[ACGT]",R)
     R <- gsub("X","[ACGT]",R)

	 RRev <- gsub("A","E",RRev)  # translate the letter code of the restriction enzyme in to the reverse letter code   
     RRev <- gsub("T","A",RRev)   
	 RRev <- gsub("E","T",RRev)   
	 RRev <- gsub("C","E",RRev)   
	 RRev <- gsub("G","C",RRev)  
	 RRev <- gsub("E","G",RRev) 
     e<-paste(rev(substring(RRev,1:nchar(RRev),1:nchar(RRev))),collapse="") #paste the translation together
						
	 e <- gsub("Y","[GA]",e)   # UipacCode for reverse letter code
     e <- gsub("R","[TC]",e)   # R is T or C
     e <- gsub("W","[AT]",e)   # W is A or T
     e <- gsub("S","[CG]",e)   # ...
     e <- gsub("K","[CA]",e)   # ... 
     e <- gsub("M","[TG]",e)   # ...
     e <- gsub("B","[CGA]",e)
     e <- gsub("D","[ACT]",e)
     e <- gsub("H","[AGT]",e)
     e <- gsub("V","[TCG]",e)
     e <- gsub("N","[ACGT]",e)
     e <- gsub("X","[ACGT]",e)
                                       
     h <- as.character(subset(allRestrictionEnzymes$Cutting,allRestrictionEnzymes$name==object@Restriction))  # search in table 'allRestrictionEnzymes' for the position of the cut.
     k <- gregexpr("\\^",h)[[1]]     # grep the place of the cut
     l <- k-1
     m <- lengt -l
     g <- data.frame(restriction  = R,    #return a data.frame with letter code of restriction enzyme, position of the cut and the same for the reverse. 
                     cut1   = l)
     return(g) }else{
     f <- "ERROR: restriction enzyme not available"
     return(f)}
     })
#---------------------------------------------------------------------------------     
   

#set generic for 'digest', you need the slots 'DNASequence' and 'Restriction'
setGeneric("digest",function(object){standardGeneric("digest")})
#----------------------------------------------------------------------------------
#set method 'digest', this method digest a DNASequence with n restriction enzymes
setMethod ("digest", "Digestion",                         
     function(object){     

               Restriction1 <- as.character(object@Restriction)      # define 'object@Restriction' as 'Restriction1', it contains the restriction enzyme(s)                               
               lengtRes <- length(Restriction1)                      # length of 'Restriction1' is the number of digestions.
               passel <- lengtRes                                    # passel is the number of digestions
               l11 <- c()
               #define data.frame  'fragmentdatas' 
               fragmentdatas <- data.frame(DNASequence=character(), RestrictionFragment=character(), Start=numeric(), EnzymeStart=character(), End=numeric(), EnzymeEnd=character(), Length=numeric())
               DNASequencelength <- length(object@DNASequence)
               Genom2 <- object@DNASequence
               p5 <-c(1,2)
               
             for(k in 1:DNASequencelength)  
             { Genom1 <- Genom2[k]
             
               DNASequencename <- k   
               Genom <- toupper(Genom1)
               
               Genomgrosse <- nchar(Genom)      # number of basepairs in the given DNASequence
               b <- 0
                    for(i in 1:lengtRes)             # do for all restriction enzymes we want to digest the DNASequence
                    {
                    if(length(Restriction1)>1)  # if there is more than one restriction enzyme per digestion, 'Restriction11' is the i-th restriction enzyme.
                    {Restriction11 <- Restriction1[i]
                    }else{
                    Restriction11 <- Restriction1} # else 'Restriction11' is the only restriction enzyme.
                    
                       if(length(grep(":",Restriction11))>0)   # if we have a double,triple, etc digestion, split both restriction enzyme at the :
                           {Restriction10 <- sapply(strsplit(Restriction11, split = ":"), function(x) as.character(x))
                           }else{Restriction10 <- Restriction11}
                            p3 <- NULL
                            p4 <- NULL
                            lo <- length(Restriction10)   # if we have a single digestion, "lo" is one. If we have a double digestion, "lo" is two, etc.
                            for(i in 1:lo)  # do for every restriction enzyme in this digestion...
                              {
                              if(length(Restriction10)>1)   # take the i-th restriction enzyme
                              {Restriction <- Restriction10[i,]
                              }else{
                              Restriction <- Restriction10}
                              a <- as.character(subset(allRestrictionEnzymes$restriction,allRestrictionEnzymes$name==Restriction))      # a is the letter code of the restriction enzyme
                              
                              if(length(a)>0)
                              {
                              if(length(p5)>1)
                              {R <- a
                              lengt <- nchar(a)
                              RRev <- a                  #translate with the UipacCode the restriction enzymes
                              R <- gsub("Y","[CT]",R)    #Y is C or T
                              R <- gsub("R","[AG]",R)    #R is A or G
                              R <- gsub("W","[AT]",R)    # ...
                              R <- gsub("S","[CG]",R)    # ...
                              R <- gsub("K","[GT]",R)    # ...
                              R <- gsub("M","[AC]",R)    # ...
                              R <- gsub("B","[CGT]",R)
                              R <- gsub("D","[AGT]",R)
                              R <- gsub("H","[ACT]",R)
                              R <- gsub("V","[ACG]",R)
                              R <- gsub("N","[ACGT]",R)
                              R <- gsub("X","[ACGT]",R)

	                          RRev <- gsub("A","E",RRev)   #translate the restriction enzyme to the transverse letter code
                              RRev <- gsub("T","A",RRev)   
	                          RRev <- gsub("E","T",RRev)   
	                          RRev <- gsub("C","E",RRev)   
	                          RRev <- gsub("G","C",RRev)  
	                          RRev <- gsub("E","G",RRev) 
                              e <- paste(rev(substring(RRev,1:nchar(RRev),1:nchar(RRev))),collapse="") #paste the translated letter code together.
						
	                          e <- gsub("Y","[GA]",e)   #UipacCode for reverse letter code
                              e <- gsub("R","[TC]",e)
                              e <- gsub("W","[AT]",e)
                              e <- gsub("S","[CG]",e)
                              e <- gsub("K","[CA]",e)
                              e <- gsub("M","[TG]",e)
                              e <- gsub("B","[CGA]",e)
                              e <- gsub("D","[ACT]",e)
                              e <- gsub("H","[AGT]",e)
                              e <- gsub("V","[TCG]",e)
                              e <- gsub("N","[ACGT]",e)
                              e <- gsub("X","[ACGT]",e)
                                       
                              h <- as.character(subset(allRestrictionEnzymes$Cutting,allRestrictionEnzymes$name==Restriction)) # search for the position of the cut of the restriction enzyme
                              k <- gregexpr("\\^",h)[[1]] # the position of the cut is given by '^', grep place of '^'.
                              l <- k-1
                              m <- lengt -l

                              f <- e
                              
                              p11 <- gregexpr(R, Genom)[[1]]        # grep the position of the restriction enzyme in the DNASequence
                              p1 <- data.frame(p11, Restriction)    # define the data.frame 'p1', which includes the restriction enzyme and the position of the cuts.
                              colnames(p1) <- c("Cut","RestrictionFragment")  # the headline is 'Cut' and 'RestrictionFragment'
                              p3 <- rbind(p1,p3)    #bind all lines of the data.frame together.
                              p22 <- gregexpr(f, Genom)[[1]]  # do the same for the reverse restriction enzyme
                              Cut <- p22
                              p2 <- data.frame(Cut, Restriction)
                              colnames(p2) <- c("Cut","RestrictionFragment")
                              p4 <- rbind(p2,p4)
                              p5 <- p4[,1]
                              }else{p5 <- 0}}else{
                              p5 <-0}
                              }

                        if(length(p5)>1)
                        {
                        l1 <- rbind(p3,p4) #bind the cuts of the reverse and the cuts of the normal restriction enzymes together
 
                         l2 <- unique(l1) #if the restriction enzymes is a palindrom, we cut at every place double, so make the data.frame unique
                         l1Rev <- l2
                         l1Rev2 <- l2
                         n1Rev <- length(l1Rev$Cut) # 'n1Rev' is the number of cuts with this restriction enzymes in the DNASequence
                         l1Rev <- l1Rev[order(l1Rev$Cut),]  # sort the data.frame 'l1Rev' by 'l1Rev$Cut'.
                         l1Rev$RestrictionFragment <- as.character(l1Rev$RestrictionFragment)            
                         beginRev <- NULL
                         endRev <- NULL
                         FragmentgrosseRev <-NULL
                         u <- NULL

                         for(j in 1:n1Rev)                      # 'l1Rev' is the place, where the restriction enzyme cuts.
                                    {                           # We need the beginning of every fragment, the end and the length of it.  
                                     beginRev[1] <- 0           # beginnig is at the first cut, end is at the second cut and length is end minus beginning.
                                     endRev[1] <- as.numeric(l1Rev$Cut[1])   
                                     beginRev[j+1] <- as.numeric(l1Rev$Cut[j])
                                     endRev[j] <- as.numeric(l1Rev$Cut[j])
                                     FragmentgrosseRev[j] <- endRev[j]-beginRev[j]
                                     }
                         beginEnzyme <- c()
                         endEnzyme <- c()
                         beginEnzyme <- as.character(beginEnzyme)
                         endEnzyme <- as.character(endEnzyme)

                         for(j in 1:n1Rev)   # define, which restriction enzyme  is for which cut responsible            
                                     {
                                     beginEnzyme[1] <- "Start"
                                     beginEnzyme[j+1] <- l1Rev$RestrictionFragment[j]
                                     endEnzyme[j] <- l1Rev$RestrictionFragment[j]
                                     }
                         endEnzyme[n1Rev+1] <- "End"
                         Genomgrosse <- nchar(Genom)
                         endRev[n1Rev+1] <- Genomgrosse         #the last cut ist the end of the chromosome                      
                         FragmentgrosseRev[n1Rev+1] <- Genomgrosse-beginRev[n1Rev+1]   #the sice of the last fragment is the DNASequence-sice minus the last cut.

                         er <- data.frame(DNASequencename, Restriction11,beginRev, beginEnzyme, endRev, endEnzyme, FragmentgrosseRev)         #we define a data.frame 'er'.
                         colnames(er) <- c("DNASequence", "RestrictionFragment","Start","EnzymeStart","End", "EnzymeEnd","Length")                 
		                 fragmentdatas <- rbind(fragmentdatas, er)
		                 a <- length(fragmentdatas$Start)
		                 }else{
		                 b <- 1} 
                   }  }                                               
                  if(b==1)
                  {
                  a <- "ERROR: One or more restriction enzymes not available."
                  return(a)
                  }else{
                  return(fragmentdatas)
                 }})    
#--------------------------------------------------------------------------------
 
#set generic for method 'plotDigest'
setGeneric("plotDigest",function(object){standardGeneric("plotDigest")})  
#-------------------------------------------------------------------------------
#set method 'plotDigest', in this function shows your digestion in a histogram
setMethod ("plotDigest", "Digestion",                                       
     function(object){ 
     er <- object@Digest              # you need to digest first the DNASequence with a restriction enzyme
     Length<- er$Length               # make a histogram with the length of the fragments.
     hist(Length, breaks = 50, freq = NULL)

})
#--------------------------------------------------------------------------------

#set generic for the method 'getName'
setGeneric("getName", function(object){standardGeneric("getName")})
#---------------------------------------------------------------------------------
#set method 'getName', you can search for the name of a restriction enzyme with the letter code of restriction enzyme
setMethod("getName", "Digestion",                                     
     function(object){
     a <- as.character(subset(allRestrictionEnzymes$name,allRestrictionEnzymes$restriction==object@RestrictionSite))    #search for the name, where the restriction code is equal to the given one
     if(length(a)>0){
     R <- a 
     
     return(R)   #return the name of the restriction enzyme
     }else{
     return("ERROR: restriction site must be wrong.")}})
#-------------------------------------------------------------------------------------       
  
  
# set generic for the method 'writeRestriction'     
setGeneric("writeRestriction", function(object){standardGeneric("writeRestriction")})  
#------------------------------------------------------------------------------------------
# set method 'writeRestriction', in this function you can write new restriction enzymes in the table 'allRestrictionEnzymes'
setMethod("writeRestriction", "Digestion",                                             
     function(object){ 
               u <- cbind(object@Restriction, object@RestrictionSite)             #bind new name, lettercode and cut of the Restriction enzymes together
           r <- cbind(u, object@Cut)
           colnames(r) <- c("name","restriction","Cutting")                   # give them the colnames like the table has.
           allRestrictionEnzymes <- rbind(allRestrictionEnzymes, r)           #bind the new Restriction enzyme with table together
             
           save(allRestrictionEnzymes, file=("allRestrictionEnzymes.rda"))    #save the table
           return(allRestrictionEnzymes)     
     })
